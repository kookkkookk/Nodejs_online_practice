var dogStatus = require("./dogStatus");


var a = 1;
var b = 4
var c = 3;
debugger;

dogStatus.bark(3);

a = 2;
b = 3 ;