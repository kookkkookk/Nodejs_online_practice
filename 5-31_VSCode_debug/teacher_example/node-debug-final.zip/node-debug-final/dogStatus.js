
var bark = function(num){
    var dogName = 'tom';
    var dogAge = 2;
    console.log('汪'+num+'次');
}

module.exports = {
    "bark": bark
}