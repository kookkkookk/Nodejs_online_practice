var firebase = require('firebase');
// 貼上自己的 config 設定
var config = {
    
};

firebase.initializeApp(config);

module.exports = firebase;